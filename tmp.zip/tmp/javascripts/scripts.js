$(document).ready(function(){

	///responsive tables!!!
	$('table').footable();


});
